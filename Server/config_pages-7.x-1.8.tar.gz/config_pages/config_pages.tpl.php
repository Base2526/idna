<?php
/**
 * @file
 * Template.
 */
?>
<?php print render($content); ?>
