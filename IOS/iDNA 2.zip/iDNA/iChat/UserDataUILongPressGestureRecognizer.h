//
//  UserDataUILongPressGestureRecognizer.h
//  CustomizingTableViewCell
//
//  Created by Somkid on 9/20/2560 BE.
//  Copyright © 2560 com.ms. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserDataUILongPressGestureRecognizer : UILongPressGestureRecognizer

@property (nonatomic, strong) id userData;
@end
