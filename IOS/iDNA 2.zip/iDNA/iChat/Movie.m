//
//  Movie.m
//  CustomizingTableViewCell
//
//  Created by abc on 28/01/15.
//  Copyright (c) 2015 com.ms. All rights reserved.
//

#import "Movie.h"

@implementation Movie

@synthesize title,poster,year;

@end
