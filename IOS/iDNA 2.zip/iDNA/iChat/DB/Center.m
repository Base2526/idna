//
//  Center.m
//  iDNA
//
//  Created by Somkid on 23/11/2560 BE.
//  Copyright © 2560 klovers.org. All rights reserved.
//

#import "Center.h"

@implementation Center

@end
