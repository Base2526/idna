//
//  Center.h
//  iDNA
//
//  Created by Somkid on 23/11/2560 BE.
//  Copyright © 2560 klovers.org. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Center : NSObject

@property (nonatomic, strong) NSString *item_id;
@property (nonatomic, strong) NSString *data;
@property (nonatomic, strong) NSString *create;
@property (nonatomic, strong) NSString *update;

@end
