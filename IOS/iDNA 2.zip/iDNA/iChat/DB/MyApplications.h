//
//  MyApplications.h
//  iDNA
//
//  Created by Somkid on 19/11/2560 BE.
//  Copyright © 2560 klovers.org. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyApplications : NSObject
@property (nonatomic, strong) NSString *app_id;
@property (nonatomic, strong) NSString *data;
@property (nonatomic, strong) NSString *create;
@property (nonatomic, strong) NSString *update;
@end
