//
//  GroupChat.m
//  iDNA
//
//  Created by Somkid on 16/11/2560 BE.
//  Copyright © 2560 klovers.org. All rights reserved.
//

#import "GroupChat.h"

@implementation GroupChat

@end
