//
//  FriendProfile.m
//  iDNA
//
//  Created by Somkid on 13/11/2560 BE.
//  Copyright © 2560 klovers.org. All rights reserved.
//

#import "FriendProfile.h"

@implementation FriendProfile

@end
