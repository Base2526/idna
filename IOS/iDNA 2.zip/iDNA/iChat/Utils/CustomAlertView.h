//
//  CustomAlertView.h
//  Heart
//
//  Created by Somkid on 1/18/2560 BE.
//  Copyright © 2560 Klovers.org. All rights reserved.
//

#import <UIKit/UIKit.h>

// http://stackoverflow.com/questions/13047527/send-a-parameter-to-an-alertview
@interface CustomAlertView : UIAlertView
@property (nonatomic, retain) id object;
@end
