//
//  ViewControllerCellHeader.m
//  ExpandableTableView
//
//  Created by milan on 05/05/16.
//  Copyright © 2016 apps. All rights reserved.
//

#import "ViewControllerCellHeader.h"

@implementation ViewControllerCellHeader
@synthesize btnShowHide, lbTitle;
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}
@end
