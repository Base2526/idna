//
//  CreateMyCardSelectPhone.h
//  Heart
//
//  Created by Somkid on 1/15/2560 BE.
//  Copyright © 2560 Klovers.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreateMyCardSelectPhone : UIViewController<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *_table;


@end
