//
//  ViewControllerCell.h
//  ExpandableTableView
//
//  Created by milan on 05/05/16.
//  Copyright © 2016 apps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewControllerCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *lblName;

@end
