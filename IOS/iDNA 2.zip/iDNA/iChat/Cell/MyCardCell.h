//
//  MyCardCell.h
//  Heart
//
//  Created by Somkid on 1/13/2560 BE.
//  Copyright © 2560 Klovers.org. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCardCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *img_select;

@end
