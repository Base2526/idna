//
//  TabStoreCell.m
//  Heart
//
//  Created by Somkid on 4/2/2560 BE.
//  Copyright © 2560 Klovers.org. All rights reserved.
//

#import "TabStoreCell.h"

@implementation TabStoreCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
