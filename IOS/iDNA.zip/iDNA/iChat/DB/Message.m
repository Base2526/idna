//
//  Message.m
//  iChat
//
//  Created by Somkid on 9/26/2560 BE.
//  Copyright © 2560 klovers.org. All rights reserved.
//

#import "Message.h"

@implementation Message
@synthesize chat_id, object_id, sender_id, receive_id, text, type, status, reader, create, update;
@end
