//
//  FriendTableViewCell.m
//  CustomizingTableViewCell
//
//  Created by Somkid on 9/23/2560 BE.
//  Copyright © 2560 com.ms. All rights reserved.
//

#import "FriendTableViewCell.h"

@implementation FriendTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
