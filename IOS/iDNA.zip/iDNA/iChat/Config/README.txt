Type DATA
-profiles           : profile ของผู้ใช้งาน
-favorite friends   : friends ที่เราชื่นชอบ
-friends            : เพื่อนทั้งหมด
-groups             : กลุ่ม Chat
-multi_chat         : คุยแบบไม่สร้างกลุ่ม
-invite_group       : กรณีมี เพื่อนเชิญเราเข้ากลุ่มสนทนา
-invite_multi_chat  : กรณีมี เพื่อนเชิญเราเข้าสนทนา

-recents            :  เก็บข้อมูลล่าสุดที่เราคุย กับเพือน กลุ่ม หรือ multi chat
