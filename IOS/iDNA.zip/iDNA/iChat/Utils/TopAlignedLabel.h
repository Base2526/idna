//
//  TopAlignedLabel.h
//  Heart
//
//  Created by Somkid on 1/15/2560 BE.
//  Copyright © 2560 Klovers.org. All rights reserved.
//

#import <UIKit/UIKit.h>
// http://stackoverflow.com/questions/28605341/vertically-align-text-within-a-uilabel-note-using-autolayout

@interface TopAlignedLabel : UILabel

@end
