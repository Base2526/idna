//
//  Cell_H_S_TabiDNA.m
//  iChat
//
//  Created by Somkid on 10/11/2560 BE.
//  Copyright © 2560 klovers.org. All rights reserved.
//

#import "Cell_H_S_TabiDNA.h"

@implementation Cell_H_S_TabiDNA

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
