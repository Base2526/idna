//
//  FollowerCell.m
//  Heart
//
//  Created by Somkid on 4/5/2560 BE.
//  Copyright © 2560 Klovers.org. All rights reserved.
//

#import "FollowerCell.h"

@implementation FollowerCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
