//
//  Cell_Item_TabiDNA.m
//  iChat
//
//  Created by Somkid on 10/11/2560 BE.
//  Copyright © 2560 klovers.org. All rights reserved.
//

#import "Cell_Item_TabiDNA.h"

@implementation Cell_Item_TabiDNA

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
