//
//  FriendHeaderTableViewCell.m
//  iChat
//
//  Created by Somkid on 3/10/2560 BE.
//  Copyright © 2560 klovers.org. All rights reserved.
//

#import "FriendHeaderTableViewCell.h"

@implementation FriendHeaderTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
