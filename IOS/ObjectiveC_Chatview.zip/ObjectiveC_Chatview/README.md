InputAccessoryExample
=====================

Sample code for figuring out how to use UIResponder's inputAccessoryView on iOS8 using Storyboards without creating leaks.
